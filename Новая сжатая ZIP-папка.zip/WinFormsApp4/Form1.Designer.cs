﻿namespace WinFormsApp4
{
    partial class Form1
    {
        /// <summary>
        ///  Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        ///  Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        ///  Required method for Designer support - do not modify
        ///  the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            btnStart = new Button();
            textBoxNumBars = new TextBox();
            flowLayoutPanel1 = new FlowLayoutPanel();
            label1 = new Label();
            SuspendLayout();
            // 
            // btnStart
            // 
            btnStart.Font = new Font("Segoe UI", 21F);
            btnStart.Location = new Point(11, 290);
            btnStart.Name = "btnStart";
            btnStart.Size = new Size(265, 40);
            btnStart.TabIndex = 0;
            btnStart.Text = "Start\r\n\r\n";
            btnStart.UseVisualStyleBackColor = true;
            btnStart.Click += btnStart_Click;
            // 
            // textBoxNumBars
            // 
            textBoxNumBars.Font = new Font("Segoe UI", 21F);
            textBoxNumBars.Location = new Point(12, 159);
            textBoxNumBars.Name = "textBoxNumBars";
            textBoxNumBars.Size = new Size(264, 45);
            textBoxNumBars.TabIndex = 1;
            // 
            // flowLayoutPanel1
            // 
            flowLayoutPanel1.Font = new Font("Segoe UI", 21F);
            flowLayoutPanel1.Location = new Point(12, 229);
            flowLayoutPanel1.Name = "flowLayoutPanel1";
            flowLayoutPanel1.Size = new Size(264, 39);
            flowLayoutPanel1.TabIndex = 2;
            // 
            // label1
            // 
            label1.AutoSize = true;
            label1.Font = new Font("Segoe UI", 21F);
            label1.Location = new Point(12, 96);
            label1.Name = "label1";
            label1.Size = new Size(210, 38);
            label1.TabIndex = 3;
            label1.Text = "Кількість Барів:";
            // 
            // Form1
            // 
            AutoScaleDimensions = new SizeF(7F, 15F);
            AutoScaleMode = AutoScaleMode.Font;
            ClientSize = new Size(300, 450);
            Controls.Add(label1);
            Controls.Add(flowLayoutPanel1);
            Controls.Add(textBoxNumBars);
            Controls.Add(btnStart);
            Name = "Form1";
            Text = "Form1";
            ResumeLayout(false);
            PerformLayout();
        }

        #endregion

        private Button btnStart;
        private TextBox textBoxNumBars;
        private FlowLayoutPanel flowLayoutPanel1;
        private Label label1;
    }
}
