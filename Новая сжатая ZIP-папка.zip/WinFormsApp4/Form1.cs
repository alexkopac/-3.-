using System;
using System.Drawing;
using System.Threading;
using System.Windows.Forms;
using System.Collections.Generic;

namespace WinFormsApp4

{
    public partial class Form1 : Form
    {

        private delegate void UpdateProgressDelegate(ProgressBar bar, int value, Label colorLabel, Color newColor);

        private List<Thread> activeThreads = new List<Thread>();
        private Random random = new Random();
        private volatile bool stopThreads = false;

        public Form1()
        {
            InitializeComponent();

            
            flowLayoutPanel1.AutoScroll = true;
            if (flowLayoutPanel1 is FlowLayoutPanel flowPanel)
            {
                flowPanel.FlowDirection = FlowDirection.TopDown;
                flowPanel.WrapContents = false;
            }

            this.FormClosing += Form1_FormClosing;




        }

        private void btnStart_Click(object sender, EventArgs e)
        {
            StopAllThreads();
            
            flowLayoutPanel1.Controls.Clear();
            activeThreads.Clear();
            stopThreads = false;

            if (!int.TryParse(textBoxNumBars.Text, out int numBars) || numBars <= 0)
            {
                MessageBox.Show("���� �����, ������ �������� ������� �������-���� (���� ����� > 0).", "������� ��������", MessageBoxButtons.OK, MessageBoxIcon.Warning);
                return;
            }

           
            for (int i = 0; i < numBars; i++)
            {
                
                ProgressBar progressBar = new ProgressBar
                {
                    Minimum = 0,
                    Maximum = 100,
                    Value = 0,
                   
                    Width = flowLayoutPanel1.ClientSize.Width - 40,
                    Height = 20,
                    Margin = new Padding(5, 0, 0, 0)
                };

               
                Label colorIndicator = new Label
                {
                    BackColor = GetRandomColor(),
                    Width = 30,
                    Height = 20,
                    Margin = new Padding(5, 5, 0, 5),
                    BorderStyle = BorderStyle.FixedSingle
                };

                FlowLayoutPanel barPanel = new FlowLayoutPanel
                {
                    
                    Width = flowLayoutPanel1.ClientSize.Width - 5,
                    Height = 30,
                    FlowDirection = FlowDirection.LeftToRight,
                    WrapContents = false
                };

                barPanel.Controls.Add(colorIndicator);
                barPanel.Controls.Add(progressBar);

                
                flowLayoutPanel1.Controls.Add(barPanel);



                Thread thread = new Thread(() => ProgressTask(progressBar, colorIndicator));
                thread.IsBackground = true;
                thread.Start();
                activeThreads.Add(thread);
            }


        }
        private void ProgressTask(ProgressBar bar, Label colorLabel)
        {
            int maxSteps = random.Next(15, 35); 
            int delayMs = random.Next(50, 150); 
            int progressStep = random.Next(3, 10); 

            for (int i = 0; i < maxSteps; i++)
            {
                
                if (stopThreads || !bar.IsHandleCreated) return;

                int newValue = Math.Min(bar.Maximum, bar.Value + progressStep);
                Color newColor = GetRandomColor();

                
                UpdateGuiSafe(bar, newValue, colorLabel, newColor);

                
                Thread.Sleep(delayMs);
            }

            
            if (!stopThreads && bar.IsHandleCreated)
            {
                UpdateGuiSafe(bar, bar.Maximum, colorLabel, GetRandomColor());
            
            }
        }

        private void UpdateGuiSafe(ProgressBar bar, int value, Label colorLabel, Color newColor)
        {
            if (bar.InvokeRequired)
            {
                this.Invoke(new UpdateProgressDelegate(UpdateGuiSafe), new object[] { bar, value, colorLabel, newColor });
            }
            else
            {
                
                bar.Value = value;
                colorLabel.BackColor = newColor;
            }

        }
        private Color GetRandomColor()
        {
            return Color.FromArgb(random.Next(256), random.Next(256), random.Next(256));
        }

        
        private void StopAllThreads()
        {
            
            stopThreads = true;

            
            activeThreads.Clear();
        }

       
        private void Form1_FormClosing(object sender, FormClosingEventArgs e)
        {
            StopAllThreads();
        }


    }
}
